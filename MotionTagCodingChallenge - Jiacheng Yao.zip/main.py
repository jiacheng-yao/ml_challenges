# -*- coding: utf-8 -*-
"""
Created on 08.12.2019

@author: Jiacheng Yao

Main Function for MotionTag Coding Challenge
"""
from model.waypoint import Waypoint
from util.csv_parser import csv_parser
from util.map_plotter import map_plotter
from util.waypoint_filter import waypoint_filter_v1, waypoint_filter_v2

from sklearn.tree import DecisionTreeClassifier

import logging

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import descartes
import geopandas as gpd

from shapely.geometry import Point, Polygon

logger = logging.getLogger()
logger.setLevel(logging.INFO)

if __name__ == "__main__":
    # 1. read the provided waypoints.csv file into list of waypoint objects.
    logging.info("1. read the provided waypoints.csv file into list of waypoint objects.")
    list_waypoints = []
    list_waypoints = csv_parser("waypoints.csv")

    # 2. plot the unfiltered waypoints on a map
    logging.info("2. plot the unfiltered waypoints on a map.")

    # read shapefile as the map background
    df_shp = gpd.read_file("gis_osm_landuse_a_free_1.shp")

    # read the waypoints
    df_waypoints = pd.read_csv('waypoints.csv', delimiter=',')

    # plot the unfiltered waypoints, normal waypoints in blue, outliers in red
    map_plotter(df_shp, df_waypoints, "waypoints_unfiltered.png")
    logging.info("2. The plot for unfiltered waypoints saved.")

    # 3. filter the waypoints
    logging.info("3. filter the waypoints.")
    df_waypoints_filtered_v1 = waypoint_filter_v1(df_waypoints)
    logging.info("3. Waypoints left after v1 Filter: "+str(df_waypoints_filtered_v1.shape[0]))
    # plot the filtered waypoints, normal waypoints in blue, outliers in red
    map_plotter(df_shp, df_waypoints_filtered_v1, "waypoints_filtered_v1.png")

    df_waypoints_filtered_v2 = waypoint_filter_v2(df_waypoints)
    logging.info("3. Waypoints left after v2 Filter: "+str(df_waypoints_filtered_v2.shape[0]))
    # plot the filtered waypoints, normal waypoints in blue, outliers in red
    map_plotter(df_shp, df_waypoints_filtered_v2, "waypoints_filtered_v2.png")
    logging.info("4. The plots for v1 and v2 versions filtered waypoints saved.")

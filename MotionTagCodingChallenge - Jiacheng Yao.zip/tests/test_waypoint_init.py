import pytest
from model.waypoint import Waypoint

def test_initial_value():
    """Test that the init function for the Waypoint class is working correctly."""
    wpt_1 = Waypoint('1', '52.491817', '13.346698', '8', '0', 'FALSE')
    assert wpt_1.id == '1'
    assert wpt_1.latitude == '52.491817'
    assert wpt_1.longitude == '13.346698'
    assert wpt_1.accuracy == '8'
    assert wpt_1.time == '0'
    assert wpt_1.outlier == 'FALSE'

def test_no_value():
    with pytest.raises(Exception) as e_info:
        wpt = Waypoint()

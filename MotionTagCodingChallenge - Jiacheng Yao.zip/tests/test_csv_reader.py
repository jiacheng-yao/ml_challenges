import os.path
import pytest
from model.waypoint import Waypoint
from util.csv_parser import csv_parser, csv_column_names
import csv
import pandas as pd
import math

input_csv = "waypoints.csv"

def test_csv_exists():
    """Test that the csv file exists."""
    assert os.path.isfile(input_csv) == True

def test_num_of_columns():
    """Test that the csv file has the correct number of columns and in the correct order."""
    assert len(csv_column_names(input_csv)) == 6

def test_column_order():
    """Test that the csv file has the correct column order."""
    cols = csv_column_names(input_csv)
    assert (cols[0] == 'id' and
            cols[1] == 'latitude' and
            cols[2] == 'longitude' and
            'accuracy' in cols[3] and
            'time' in cols[4] and
            cols[5] == 'outlier')

def test_csv_parser():
    """Test that the csv parser works properly."""
    df = pd.read_csv('waypoints.csv', delimiter=',')
    list_waypoints = csv_parser(input_csv)

    # check the number of rows
    assert df.shape[0] == len(list_waypoints)
    # check the content of the objects
    for i in range(50):
        tmp_real_row = df.iloc[i]
        tmp_test_row = list_waypoints[i]
        assert tmp_real_row['id'] == int(tmp_test_row.id)
        assert math.isclose(float(tmp_test_row.latitude), tmp_real_row['latitude'], rel_tol=1e-6)
        assert math.isclose(float(tmp_test_row.longitude), tmp_real_row['longitude'], rel_tol=1e-6)
        assert str(tmp_real_row['accuracy (m)']) == tmp_test_row.accuracy
        assert str(tmp_real_row['time (min)']) == tmp_test_row.time
        assert str(tmp_real_row['outlier']).upper() == tmp_test_row.outlier.upper()

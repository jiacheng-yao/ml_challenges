import csv
import logging
from model.waypoint import Waypoint

def csv_column_names(input_csv):
    """Extract Column Names."""
    with open(input_csv, mode='r') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            if line_count == 0:
                return row

def csv_parser(input_csv):
    """Parse the csv file waypoints and return the waypoints as a list of Waypoint objects."""
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logging.info("Reading waypoints.csv")

    list_waypoints = []
    with open(input_csv, mode='r') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            if line_count == 0:
                line_count += 1
            else:
                list_waypoints.append(Waypoint(row[0],
                                               row[1],
                                               row[2],
                                               row[3],
                                               row[4],
                                               row[5]))
                line_count += 1
        logging.info(f'Processed {line_count} lines.')
        return list_waypoints

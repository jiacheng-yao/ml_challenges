import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import descartes
import geopandas as gpd

from shapely.geometry import Point, Polygon

def map_plotter(df_shp, df_waypoints, plot_output):
    """
    Plots the waypoints with shapefile as map background
    :param df_shp: background shapefile in geopandas.GeoDataFrame format
    :param df_waypoints: waypoints in pandas.DataFrame format
    :return: None
    """
    crs ={'init': 'epsg:4326'}

    # generate the geometry for the waypoints
    geometry = [Point(xy) for xy in zip(df_waypoints['longitude'], df_waypoints['latitude'])]
    # convert original waypoints dataframe to GeoDataFrame
    geo_df_waypoints = gpd.GeoDataFrame(df_waypoints, crs = crs, geometry = geometry)

    fig, ax = plt.subplots(figsize = (15, 15))
    df_shp.plot(ax = ax, alpha = 0.4, color = 'grey')
    geo_df_waypoints[geo_df_waypoints['outlier'] == True].plot(ax = ax, markersize = 20, color = 'red', marker = 'o', label = 'Outlier')
    geo_df_waypoints[geo_df_waypoints['outlier'] == False].plot(ax = ax, markersize = 20, color = 'blue', marker = '^', label = 'Normal')
    plt.legend(prop = {'size': 15})

    plt.savefig(plot_output)


def make_waypoints_map(date, df, ax=None, resolution='low'):
    """
    Plots waypoints up to a certain minute
    :param date: up to which minute will the current frame plot
    :param df: waypoints in pandas.DataFrame format
    :return: None
    """
    if ax is None:
        fig, ax = plt.subplots(figsize = (15, 15))

    df_filtered = df[df['time (min)'] < date]
    crs ={'init': 'epsg:4326'}

    geometry_filtered = [Point(xy) for xy in zip(df_filtered['longitude'], df_filtered['latitude'])]

    geo_df_filtered = gpd.GeoDataFrame(df_filtered, crs = crs, geometry = geometry_filtered)

    df_shp.plot(ax = ax, alpha = 0.4, color = 'grey')
    geo_df_filtered[geo_df_filtered['outlier'] == True].plot(ax = ax, markersize = 20, color = 'red', marker = 'o', label = 'Outlier')
    geo_df_filtered[geo_df_filtered['outlier'] == False].plot(ax = ax, markersize = 20, color = 'blue', marker = '^', label = 'Normal')
    plt.legend(prop = {'size': 15})

def make_map_frames(df):
    """
    Generate all the frames for preparation of film creation
    The purpose of this optional function is to gain insight to the temporal development of the waypoints.
    All the frames in .png format will be saved in frames subrepository. 
    :param df: waypoints in pandas.DataFrame format
    :return: None
    """
    for i in range(max(df['time (min)']+1)):
        fig, ax = plt.subplots(figsize = (15, 15))
        date = df['time (min)'][i]
        ax = make_waypoints_map(date, df, ax=ax, resolution='full')
        fig.tight_layout(pad=-0.5)
        fig.savefig(f"frames/frame_{i:04d}.png", dpi=100,
                    frameon=False, facecolor='black')
        if(ax is not None):
            ax.clear()
    # after the frames have been created, a film can be created by the following
    # command: ffmpeg -framerate 21 -i frames/frame_%4d.png -c:v h264 -r 30 -s 1920x1080 ./waypoints.mp4

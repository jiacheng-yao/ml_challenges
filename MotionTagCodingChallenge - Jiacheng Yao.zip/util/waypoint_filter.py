from sklearn.tree import DecisionTreeClassifier

import numpy as np
import pandas as pd

import sklearn

from math import radians, cos, sin, asin, sqrt

def waypoint_filter_v1(df_waypoints):
    """
    First Waypoint Filter Approach, decision tree using lat, lon, accuracy and time as features
    :param df_waypoints: waypoints in DataFrame format to be filtered
    :return: df_filtered in DataFrame format
    """
    df_features = df_waypoints.iloc[:, 1:5]
    df_label = df_waypoints.iloc[:, 5]

    dtree = DecisionTreeClassifier(criterion = 'gini', max_depth= 1, max_features = 3)
    dtree.fit(df_features, df_label)

    y_pred = dtree.predict(df_features)
    y_true = df_label

    df_filtered = df_waypoints[~y_pred]

    return df_filtered

def haversine(lon1, lat1, lon2, lat2):
    """
    Calculate the great circle distance between two points
    on the earth (specified in decimal degrees)
    """
    # convert decimal degrees to radians
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])

    # haversine formula
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a))
    r = 6371 # Radius of earth in kilometers. Use 3956 for miles
    return c * r

def waypoint_filter_v2(df_waypoints):
    """
    Second Waypoint Filter Approach, first filter with accuracy, based on the learnings from waypoint_filter_v1,
    and then check if the move between coordinates is realistic.
    Essentially testing if two given circles with coordinates as centers touch or intersect each other,
    accounting for accuracy radius and realistic movement range per minute.
    :param df_waypoints: waypoints in DataFrame format to be filtered
    :return: df_filtered in DataFrame format
    """
    df_waypoints_f_tmp = df_waypoints[df_waypoints['accuracy (m)'] < 52.5]

    tmp_lon = df_waypoints_f_tmp.iloc[0]['longitude']
    tmp_lat = df_waypoints_f_tmp.iloc[0]['latitude']
    tmp_acc = df_waypoints_f_tmp.iloc[0]['accuracy (m)']
    tmp_time = df_waypoints_f_tmp.iloc[0]['time (min)']

    results = []
    results.append(False)

    for i in range(df_waypoints_f_tmp.shape[0]-1):
        dist = haversine(tmp_lon, tmp_lat,
                         df_waypoints_f_tmp.iloc[i+1]['longitude'],
                         df_waypoints_f_tmp.iloc[i+1]['latitude']) * 1000
        delta_t = df_waypoints_f_tmp.iloc[i+1]['time (min)'] - tmp_time
        rad = tmp_acc + df_waypoints_f_tmp.iloc[i+1]['accuracy (m)'] + delta_t*1.4*60*8

        if (dist > rad):
            results.append(True)
        else:
            results.append(False)

            # only update tmp_data when the new waypoint has been confirmed as non-outlier
            tmp_lon = df_waypoints_f_tmp.iloc[i]['longitude']
            tmp_lat = df_waypoints_f_tmp.iloc[i]['latitude']
            tmp_acc = df_waypoints_f_tmp.iloc[i]['accuracy (m)']
            tmp_time = df_waypoints_f_tmp.iloc[i]['time (min)']

    df_filtered = df_waypoints_f_tmp[~np.array(results)]
    return df_filtered

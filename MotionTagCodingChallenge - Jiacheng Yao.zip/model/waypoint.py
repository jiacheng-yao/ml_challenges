class Waypoint:
    def __init__(self, id, latitude, longitude, accuracy, time, outlier):
        self.id = id
        self.latitude = latitude
        self.longitude = longitude
        self.accuracy = accuracy
        self.time = time
        self.outlier = outlier   

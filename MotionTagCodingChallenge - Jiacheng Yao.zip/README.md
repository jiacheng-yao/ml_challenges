# Solutions to MotionTag Coding Challenge by Jiacheng Yao - 08.12.2019
1. The solutions are all in python 3. Do remember to install all the necessary packages:
    ```
    pip install -r requirements.txt
    ```
    or  
    ```
    ~/anaconda3/bin/pip install -r requirements.txt
    ```
    if you are working with anaconda3 python.
2. main.py is the main function that produces the unfiltered plot, conducts the filtering and redoes the plots.
3. main.py imports Waypoint class from model/waypoint.py, as well as various util functions from util subrepository
4. for the plots, a shapefile data is used as reference background - gis_osm_landuse_a_free_1.shp
5. two filtering functions have been written in util/waypoint_filter.py.
  - waypoint_filter_v1 is a simple function that explores the waypoints.csv dataset and it aims to find patterns between the features and the label outlier. The hyperparameter optimization for the decision tree as well as the visualization of the optimal decision tree can be found in the Motiontag - Solutions.ipynb notebook.
  - waypoint_filter_v2 is based on the findings from the decision tree in waypoint_filter_v1, which means it filters out a subset of outliers based on the accuracy column and then check if the move between coordinates is realistic. Essentially testing if two given circles with coordinates as centers touch or intersect each other, accounting for accuracy radius and realistic movement range per minute.
6. main results include:
  - waypoints_unfiltered.png - plot for the unfiltered waypoints
  - waypoints_filtered_v1.png - plot for the waypoints filtered with waypoint_filter_v1() function
  - waypoints_filtered_v2.png - plot for the waypoints filtered with waypoint_filter_v2() function
  - waypoints_unfiltered.mp4 - film depicting the temporal development of the waypoints, optional, can be generated with make_map_frames function in util/map_plotter.py and the following command:
    ```
    ffmpeg -framerate 21 -i frames/frame_%4d.png -c:v h264 -r 30 -s 1920x1080 ./waypoints_unfiltered.mp4
    ```
